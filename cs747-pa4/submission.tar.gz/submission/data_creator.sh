python3 generate_data.py --num_action 4 --stochasticity 0
python3 generate_data.py --num_action 8 --stochasticity 0
python3 generate_data.py --num_action 8 --stochasticity 1
